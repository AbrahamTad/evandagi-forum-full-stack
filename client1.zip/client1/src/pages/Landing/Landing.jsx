
import React, { useState } from "react";
import Login from "../Login/Login";
import Register from "../Register/Register";
import classes from "./landing.module.css";

const Landing = () => {
  const [currentView, setCurrentView] = useState("signIn"); // Default to Sign In

  const switchToSignUp = () => setCurrentView("signUp");
  const switchToSignIn = () => setCurrentView("signIn");

  return (
    <main className={`container-fluid ${classes.landing}`}>
      <div className="row align-items-center justify-content-center min-vh-100">
        {/* Form Section */}
        <div className="col-lg-5 col-md-6 col-sm-12 mb-4">
          <div className={classes["form-container"]}>
            <div className={classes["form-wrapper"]}>
              {currentView === "signIn" ? (
                <Login switchToSignUp={switchToSignUp} />
              ) : (
                <Register switchToSignIn={switchToSignIn} />
              )}
            </div>
          </div>
        </div>

        {/* Info Section */}
        <div className="col-lg-5 col-md-6 col-sm-12 text-center text-lg-start">
          <div className={classes.info}>
            <h4>About</h4>
            <h1>Evangadi Networks</h1>
            <p>
              No matter what stage of life you are in, whether you’re just
              starting elementary school or being promoted to CEO of a Fortune
              500 company, you have much to offer to those who are trying to
              follow in your footsteps.
            </p>
            <p>
              Whether you are willing to share your knowledge or you are just
              looking to meet mentors of your own, please start by joining the
              network here.
            </p>
            <button>HOW IT WORKS</button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Landing;




// import React, { useState } from "react";
// import Login from "../Login/Login";
// import Register from "../Register/Register";
// import classes from "./landing.module.css";

// const Landing = () => {
//   const [currentView, setCurrentView] = useState("signIn"); // Default to Sign In

//   const switchToSignUp = () => setCurrentView("signUp");
//   const switchToSignIn = () => setCurrentView("signIn");

//   return (
//     <>

//       <main>
//         <div className={classes["form-container"]}>
//           <div className={classes["form-wrapper"]}>
//             {currentView === "signIn" ? (
//               <Login switchToSignUp={switchToSignUp} />
//             ) : (
//               <Register switchToSignIn={switchToSignIn} />
//             )}
//           </div>
//         </div>
//         <div className={classes.info}>
//           <h4>About</h4>
//           <h1>Evangadi Networks</h1>
//           <p>
//             No matter what stage of life you are in, whether you’re just
//             starting elementary school or being promoted to CEO of a Fortune 500
//             company, you have much to offer to those who are trying to follow in
//             your footsteps.
//           </p>
//           <p>
//             Whether you are willing to share your knowledge or you are just
//             looking to meet mentors of your own, please start by joining the
//             network here.
//           </p>
//           <button>HOW IT WORKS</button>
//         </div>
//       </main>

//     </>
//   );
// };

// export default Landing;
