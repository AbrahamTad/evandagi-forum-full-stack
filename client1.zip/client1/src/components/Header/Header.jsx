import React, { useState, useEffect } from "react";
import { Navbar, Nav, Container, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import Logo from "../../assets/images/EvangadiLogo.png";
import classes from "./header.module.css";

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Manage login state
  const navigate = useNavigate(); // React Router hook for navigation

  useEffect(() => {
    // Check if the user is logged in (based on stored token)
    const token = localStorage.getItem("authToken");
    if (token) {
      setIsLoggedIn(true); // Set logged-in state to true if token exists
    }
  }, []);

  const handleSignOut = () => {
    // Clear the authentication token
    localStorage.removeItem("authToken"); // Remove token from localStorage

    // Set logged-in state to false
    setIsLoggedIn(false);

    // Redirect to the login page after sign-out
    navigate("/"); // Redirect to the login page
  };

  return (
    <Navbar bg="white" expand="lg" sticky="top" className={classes.navbar}>
      <Container>
        {/* Logo */}
        <Navbar.Brand href="/">
          <img src={Logo} alt="Evangadi Logo" className={classes.logo} />
        </Navbar.Brand>

        {/* Toggle Button for Mobile */}
        <Navbar.Toggle aria-controls="basic-navbar-nav" />

        {/* Navigation Links */}
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link as={Link} to="/" className={classes.navLink}>
              Home
            </Nav.Link>
            <Nav.Link href="/how-it-works" className={classes.navLink}>
              How it Works
            </Nav.Link>
            {!isLoggedIn ? (
              <Nav.Link
                as={Link}
                to="/"
                className={`d-none d-lg-inline-block ${classes.signIn}`}
              >
                Sign In
              </Nav.Link>
            ) : (
              <Button
                variant="outline-primary"
                className={`d-none d-lg-inline-block ${classes.signOut}`}
                onClick={handleSignOut}
              >
                Sign Out
              </Button>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;

// import React from "react";
// import { Navbar, Nav, Container } from "react-bootstrap";
// import { Link } from "react-router-dom";
// import Logo from "../../assets/images/EvangadiLogo.png";
// import classes from "./header.module.css";

// const Header = () => {
//   return (
//     <Navbar bg="white" expand="lg" sticky="top" className={classes.navbar}>
//       <Container>
//         {/* Logo */}
//         <Navbar.Brand href="/">
//           <img src={Logo} alt="Evangadi Logo" className={classes.logo} />
//         </Navbar.Brand>

//         {/* Toggle Button for Mobile */}
//         <Navbar.Toggle aria-controls="basic-navbar-nav" />

//         {/* Navigation Links */}
//         <Navbar.Collapse id="basic-navbar-nav">
//           <Nav className="ms-auto">
//             <Nav.Link as={Link} to="/" className={classes.navLink}>
//               Home
//             </Nav.Link>
//             <Nav.Link href="#" className={classes.navLink}>
//               How it Works
//             </Nav.Link>
//             <Nav.Link
//               as={Link}
//               to="/ask"
//               className={`d-none d-lg-inline-block ${classes.signIn}`}
//             >
//               Sign In
//             </Nav.Link>
//           </Nav>
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// };

// export default Header;

// import React from "react";
// import { Link } from "react-router-dom";
// import classes from "./header.module.css";
// import Logo from "../../assets/images/EvangadiLogo.png";

// const Header = () => {
//   return (
//     <header className={classes.header}>
//       <div className={classes.navbar}>
//         {/* Logo */}
//         <div className={classes.logo}>
//           <Link to="/">
//             <img src={Logo} alt="Evangadi Logo" />
//           </Link>
//         </div>

//         {/* Navigation Links */}
//         <nav className={classes.navLinks}>
//           <Link to="/home" className={classes.navLink}>
//             Home
//           </Link>
//           <Link to="/how-it-works" className={classes.navLink}>
//             How It Works
//           </Link>
//           <Link to="/" className={`${classes.navLink} ${classes.signIn}`}>
//             Sign In
//           </Link>
//         </nav>
//       </div>
//     </header>
//   );
// };

// export default Header;

// import React from "react";
// import { Link } from "react-router-dom";
// import classes from "./header.module.css";
// import Logo from "../../assets/images/EvangadiLogo.png";
// import { Navbar, Nav, Dropdown, DropdownButton } from "react-bootstrap";  // Import Bootstrap components

// const Header = () => {
//   return (
//     <header className={classes.header}>
//       <Navbar bg="light" expand="md" className="w-100">
//         {/* Logo in the center */}
//         <Navbar.Brand href="/" className="mx-auto">
//           <img src={Logo} alt="Evangadi Logo" className={classes.logo} />
//         </Navbar.Brand>

//         {/* Mobile Dropdown Menu for other links */}
//         <Navbar.Toggle aria-controls="navbar-nav" />
//         <Navbar.Collapse id="navbar-nav">
//           <Nav className="ms-auto">
//             <DropdownButton
//               drop="down"
//               variant="link"
//               id="dropdown-custom-components"
//               className={classes.dropdown}
//             >
//               <Dropdown.Item as={Link} to="/home" className={classes.navLink}>
//                 Home
//               </Dropdown.Item>
//               <Dropdown.Item as={Link} to="/how-it-works" className={classes.navLink}>
//                 How It Works
//               </Dropdown.Item>
//               <Dropdown.Item as={Link} to="/" className={`${classes.navLink} ${classes.signIn}`}>
//                 Sign In
//               </Dropdown.Item>
//             </DropdownButton>
//           </Nav>
//         </Navbar.Collapse>
//       </Navbar>
//     </header>
//   );
// };

// export default Header;

// import React from "react";
// import { Link } from "react-router-dom";
// import classes from "./header.module.css";
// import Logo from "../../assets/images/EvangadiLogo.png";

// const Header = () => {
//   return (
//     <header>
//       <div className={classes.logo}>
//         <Link to="/">
//           <img src={Logo} alt="Evangadi Logo" />
//         </Link>
//       </div>
//       <nav>
//         <Link to="/home">Home</Link>
//         <Link to="/how-it-works">How it Works</Link>
//         <Link to="/" className={classes.sign__in}>
//           Sign In
//         </Link>
//       </nav>
//     </header>
//   );
// };

// export default Header;

// import React from 'react'
// import classes from "./header.module.css"
// import Logo from "../../assets/images/EvangadiLogo.png";
// import { Link } from 'react-router-dom';
// import HowItWorks from '../../pages/HowItWorks/HowItWorks';

// const Header = () => {
//   return (
//     <>
//       <header>
//         <div className={classes.logo}>
//           <a href="/">
//             <img src={Logo} alt="" />
//           </a>
//         </div>
//         <nav>
//           <a href="home">Home</a>
//           <a href="HowItWorks">How it works</a>
//           <a href="/" className={classes.sign__in}>
//             Sign In
//           </a>
//         </nav>
//       </header>
//     </>
//   );
// }

// export default Header
