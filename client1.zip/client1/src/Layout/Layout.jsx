import React from "react";
import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";

// const Layout = ({ children }) => {
//   return (
//     <>
//       <Header />
//       <main>{children}</main>
//       <Footer />
//     </>
//   );
// };

// export default Layout;
function Layout({children}) {
  return (
    <div>
      <Header/>
      <div style={{minHeight:"100vh !important"}}>
      {children}
      </div>
      <Footer/>
    </div>
  )
}

export default Layout

